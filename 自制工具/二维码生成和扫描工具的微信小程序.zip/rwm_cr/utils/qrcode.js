// utils/qrcode.js - 二维码绘制封装
const utf8 = require('./utf8.js');
const qrcodeGenerator = require('./qrcode-generator.js');

/**
 * 绘制二维码到指定 canvas
 * @param {string} text 要编码的文本
 * @param {string} canvasId canvas 组件的 id
 * @param {number} width 画布宽度(px)
 * @param {number} height 画布高度(px)
 * @param {function} callback 绘制完成回调 (error)
 */
function drawQrcode(text, canvasId, width, height, callback) {
  // 1. 将文本转为 UTF-8 字节数组
  const bytes = utf8.stringToBytes(text);
  
  // 2. 将字节数组转换为字符串（每个字节作为单个字符）
  let byteString = '';
  for (let i = 0; i < bytes.length; i++) {
    byteString += String.fromCharCode(bytes[i]);
  }
  
  // 3. 创建 QRCode 对象（使用 'M' 纠错等级，可根据需要调整）
  const qr = qrcodeGenerator(0, 'M');
  qr.addData(byteString, 'Byte');
  qr.make();
  
  // 4. 获取矩阵尺寸和模块数
  const size = qr.getModuleCount();
  const cellSize = Math.min(width, height) / size; // 每个格子大小
  
  // 5. 获取 canvas 上下文并绘制
  const ctx = wx.createCanvasContext(canvasId);
  
  // 清空画布（设置白色背景）
  ctx.setFillStyle('#ffffff');
  ctx.fillRect(0, 0, width, height);
  
  // 绘制黑色模块
  ctx.setFillStyle('#000000');
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (qr.isDark(row, col)) {
        ctx.fillRect(
          col * cellSize, 
          row * cellSize, 
          cellSize, 
          cellSize
        );
      }
    }
  }
  
  // 6. 执行绘制
  ctx.draw(false, (err) => {
    if (callback) callback(err);
  });
}

module.exports = {
  draw: drawQrcode
};