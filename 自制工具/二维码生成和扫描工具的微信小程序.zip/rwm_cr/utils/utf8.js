// utils/utf8.js - 将字符串转换为UTF-8字节数组
function stringToBytes(str) {
  const bytes = [];
  for (let i = 0; i < str.length; i++) {
    const c = str.charCodeAt(i);
    if (c < 0x80) {
      bytes.push(c);
    } else if (c < 0x800) {
      bytes.push(0xc0 | (c >> 6), 0x80 | (c & 0x3f));
    } else if (c < 0xd800 || c >= 0xe000) {
      bytes.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f));
    } else {
      // 处理代理对（emoji等）
      i++;
      const c2 = str.charCodeAt(i);
      const combined = ((c & 0x3ff) << 10) | (c2 & 0x3ff) + 0x10000;
      bytes.push(
        0xf0 | (combined >> 18),
        0x80 | ((combined >> 12) & 0x3f),
        0x80 | ((combined >> 6) & 0x3f),
        0x80 | (combined & 0x3f)
      );
    }
  }
  return bytes;
}

module.exports = {
  stringToBytes
};