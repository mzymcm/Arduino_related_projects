// app.js
App({
  onLaunch() {
    // 初始化时执行的逻辑
    console.log('小程序启动');
  },
  globalData: {
    // 全局数据
  }
});