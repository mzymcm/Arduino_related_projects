// pages/index/index.js
const qrcode = require('../../utils/qrcode.js');

Page({
  data: {
    inputText: '你好，世界！', // 默认文本含汉字
    scanResult: '',            // 扫描结果
    canvasWidth: 300,          // 画布宽度，与wxml保持一致
    canvasHeight: 300          // 画布高度
  },

  // 输入框变化
  onInputChange(e) {
    this.setData({
      inputText: e.detail.value
    });
  },

  // 生成二维码
  generateQRCode() {
    const { inputText, canvasWidth, canvasHeight } = this.data;
    if (!inputText.trim()) {
      wx.showToast({ title: '请输入内容', icon: 'none' });
      return;
    }

    // 显示加载提示
    wx.showLoading({ title: '生成中...' });

    // 调用封装的二维码绘制函数
  qrcode.draw(inputText, 'qrCanvas', canvasWidth, canvasHeight, (res) => {
      wx.hideLoading();
      // 判断绘制结果：成功时 res.errMsg 为 "drawCanvas:ok"
      if (res && res.errMsg === 'drawCanvas:ok') {
        wx.showToast({ title: '生成成功', icon: 'success' });
      } else {
        wx.showToast({ title: '生成失败', icon: 'none' });
        console.error('二维码生成失败', res);
      }
    });
  },

  // 扫描二维码
  scanCode() {
    wx.scanCode({
      onlyFromCamera: false,   // 允许从相册选择
      scanType: ['qrCode'],    // 只扫描二维码
      success: (res) => {
        this.setData({
          scanResult: res.result  // 扫描结果（汉字自动解码）
        });
        wx.showToast({ title: '扫描成功', icon: 'success' });
      },
      fail: (err) => {
        if (err.errMsg.indexOf('cancel') === -1) {
          wx.showToast({ title: '扫描失败', icon: 'none' });
        }
      }
    });
  },

  // 页面加载时默认生成一次二维码
  onLoad() {
    // 等待画布初始化完成后生成默认二维码
    setTimeout(() => {
      this.generateQRCode();
    }, 500);
  }
});