// pages/index/index.js
const QRCode = require('../../utils/qrcode.js');

Page({
  data: {
    text: 'https://example.com',
    generating: false,
    hasCode: false,
    tip: ''
  },

  onLoad() {
    this.generateCode();
  },

  onInput(e) {
    this.setData({
      text: e.detail.value,
      hasCode: false,
      tip: ''
    });
  },

  generateCode() {
    const { text } = this.data;
    if (!text.trim()) {
      this.setData({ tip: '请输入内容' });
      return;
    }

    this.setData({ generating: true, tip: '' });

    try {
      // 创建二维码对象（版本0自动选择，纠错等级'H'）
      const qr = new QRCode(0, 'H');
      qr.addData(text);
      qr.make();

      const matrix = qr.modules; // 直接访问 modules 属性
      const n = qr.getModuleCount();
      const size = 300;
      const cellSize = size / n;

      const ctx = wx.createCanvasContext('qrcode');
      ctx.setFillStyle('#ffffff');
      ctx.fillRect(0, 0, size, size);

      ctx.setFillStyle('#000000');
      for (let row = 0; row < n; row++) {
        for (let col = 0; col < n; col++) {
          if (matrix[row][col]) {
            ctx.fillRect(col * cellSize, row * cellSize, cellSize, cellSize);
          }
        }
      }

      ctx.draw(false, () => {
        console.log('二维码绘制完成');
        this.setData({ generating: false, hasCode: true });
      });

    } catch (err) {
      console.error(err);
      this.setData({ generating: false, tip: '错误: ' + err.message });
    }
  },

  saveCode() {
    wx.getSetting({
      success: (res) => {
        if (res.authSetting['scope.writePhotosAlbum']) {
          this.saveImage();
        } else {
          wx.authorize({
            scope: 'scope.writePhotosAlbum',
            success: () => this.saveImage(),
            fail: () => {
              wx.showModal({
                title: '需要权限',
                content: '请授权保存到相册',
                success: (modal) => {
                  if (modal.confirm) wx.openSetting();
                }
              });
            }
          });
        }
      }
    });
  },

  saveImage() {
    wx.canvasToTempFilePath({
      canvasId: 'qrcode',
      success: (res) => {
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
          success: () => wx.showToast({ title: '保存成功' }),
          fail: () => wx.showToast({ title: '保存失败', icon: 'none' })
        });
      },
      fail: () => wx.showToast({ title: '生成图片失败', icon: 'none' })
    }, this);
  }
});