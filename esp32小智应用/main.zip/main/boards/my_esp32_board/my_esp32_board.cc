#include "wifi_board.h"
#include "codecs/no_audio_codec.h"
#include "system_reset.h"
#include "application.h"
#include "button.h"
#include "config.h"
#include "led/single_led.h"
#include "display/oled_display.h"
#include "assets/lang_config.h"

#include <esp_log.h>
#include <esp_timer.h>
#include <driver/i2c_master.h>
#include <driver/uart.h>
#include <esp_lcd_panel_ops.h>
#include <esp_lcd_panel_vendor.h>
#include <cstring>

#define TAG "MyESP32Board"

// UART 缓冲区大小
#define UART_BUF_SIZE 1024

class MyEsp32Board : public WifiBoard {
private:
    Button boot_button_;
    i2c_master_bus_handle_t display_i2c_bus_;
    esp_lcd_panel_io_handle_t panel_io_ = nullptr;
    esp_lcd_panel_handle_t panel_ = nullptr;
    Display* display_ = nullptr;
    TaskHandle_t uart_task_handle_ = nullptr;
    bool uart_running_ = true;

    void InitializeDisplayI2c() {
        i2c_master_bus_config_t bus_config = {
            .i2c_port = (i2c_port_t)0,
            .sda_io_num = OLED_SDA_PIN,
            .scl_io_num = OLED_SCL_PIN,
            .clk_source = I2C_CLK_SRC_DEFAULT,
            .glitch_ignore_cnt = 7,
            .intr_priority = 0,
            .trans_queue_depth = 0,
            .flags = {
                .enable_internal_pullup = 1,
            },
        };
        ESP_ERROR_CHECK(i2c_new_master_bus(&bus_config, &display_i2c_bus_));
    }

    void InitializeSsd1306Display() {
        esp_lcd_panel_io_i2c_config_t io_config = {
            .dev_addr = OLED_I2C_ADDR,
            .on_color_trans_done = nullptr,
            .user_ctx = nullptr,
            .control_phase_bytes = 1,
            .dc_bit_offset = 6,
            .lcd_cmd_bits = 8,
            .lcd_param_bits = 8,
            .flags = {
                .dc_low_on_data = 0,
                .disable_control_phase = 0,
            },
            .scl_speed_hz = 400 * 1000,
        };

        ESP_ERROR_CHECK(esp_lcd_new_panel_io_i2c_v2(display_i2c_bus_, &io_config, &panel_io_));

        esp_lcd_panel_dev_config_t panel_config = {};
        panel_config.reset_gpio_num = OLED_RST_PIN;
        panel_config.bits_per_pixel = 1;

        esp_lcd_panel_ssd1306_config_t ssd1306_config = {
            .height = static_cast<uint8_t>(OLED_RESOLUTION_HEIGHT),
        };
        panel_config.vendor_config = &ssd1306_config;

        ESP_ERROR_CHECK(esp_lcd_new_panel_ssd1306(panel_io_, &panel_config, &panel_));
        ESP_ERROR_CHECK(esp_lcd_panel_reset(panel_));
        ESP_ERROR_CHECK(esp_lcd_panel_init(panel_));
        ESP_ERROR_CHECK(esp_lcd_panel_disp_on_off(panel_, true));

        display_ = new OledDisplay(panel_io_, panel_, OLED_RESOLUTION_WIDTH, OLED_RESOLUTION_HEIGHT,
                                   DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y);
    }

    void InitializeButtons() {
        boot_button_.OnClick([this]() {
            auto& app = Application::GetInstance();
            if (app.GetDeviceState() == kDeviceStateStarting) {
                EnterWifiConfigMode();
                return;
            }
            app.ToggleChatState();
        });
    }

    void InitializeLed() {
        gpio_config_t led_config = {
            .pin_bit_mask = (1ULL << LED_CONTROL_GPIO),
            .mode = GPIO_MODE_OUTPUT,
            .pull_up_en = GPIO_PULLUP_DISABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type = GPIO_INTR_DISABLE,
        };
        gpio_config(&led_config);
        // 初始状态：熄灭
        gpio_set_level(LED_CONTROL_GPIO, 0);
    }

    void InitializeAudioPower() {
        gpio_config_t pa_config = {
            .pin_bit_mask = (1ULL << AUDIO_PA_ENABLE_PIN),
            .mode = GPIO_MODE_OUTPUT,
            .pull_up_en = GPIO_PULLUP_DISABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type = GPIO_INTR_DISABLE,
        };
        gpio_config(&pa_config);
        gpio_set_level(AUDIO_PA_ENABLE_PIN, 1);  // 使能功放
    }

    void InitializeUart() {
        uart_config_t uart_config = {
            .baud_rate = UART1_BAUD_RATE,
            .data_bits = UART_DATA_8_BITS,
            .parity = UART_PARITY_DISABLE,
            .stop_bits = UART_STOP_BITS_1,
            .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
            .source_clk = UART_SCLK_DEFAULT,
        };
        ESP_ERROR_CHECK(uart_driver_install(UART_NUM_1, UART_BUF_SIZE, UART_BUF_SIZE, 10, NULL, 0));
        ESP_ERROR_CHECK(uart_param_config(UART_NUM_1, &uart_config));
        ESP_ERROR_CHECK(uart_set_pin(UART_NUM_1, UART1_TX_PIN, UART1_RX_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));

        // 注册 UART 发送回调，供 Application 调用
        Application::GetInstance().RegisterUartSendCallback([this](const std::string& text) {
            SendUartText(text);
        });

        // 创建 UART 接收任务
        xTaskCreate([](void* arg) {
            auto* board = static_cast<MyEsp32Board*>(arg);
            board->UartReceiveTask();
        }, "uart_rx", 4096, this, 3, &uart_task_handle_);
    }

    void UartReceiveTask() {
        uint8_t buffer[UART_BUF_SIZE];
        std::string line_buffer;

        while (uart_running_) {
            int len = uart_read_bytes(UART_NUM_1, buffer, UART_BUF_SIZE - 1, pdMS_TO_TICKS(100));
            if (len > 0) {
                buffer[len] = '\0';
                line_buffer += reinterpret_cast<char*>(buffer);

                // 按行处理（以 '\n' 为分隔符）
                size_t pos;
                while ((pos = line_buffer.find('\n')) != std::string::npos) {
                    std::string line = line_buffer.substr(0, pos);
                    line_buffer.erase(0, pos + 1);

                    // 去除末尾的 '\r'
                    if (!line.empty() && line.back() == '\r') line.pop_back();
                    if (!line.empty()) {
                        ESP_LOGI(TAG, "UART received: %s", line.c_str());
                        // 将收到的文本交给 Application 处理（发送给 AI）
                        Application::GetInstance().OnUartTextReceived(line);
                    }
                }
            }
        }
    }

public:
    MyEsp32Board() : WifiBoard(), boot_button_(BUILTIN_BUTTON_GPIO) {
        InitializeDisplayI2c();
        InitializeSsd1306Display();
        InitializeButtons();
        InitializeLed();
        InitializeAudioPower();
        InitializeUart();
    }

    ~MyEsp32Board() {
        uart_running_ = false;
        if (uart_task_handle_) {
            vTaskDelete(uart_task_handle_);
        }
        uart_driver_delete(UART_NUM_1);
    }

virtual AudioCodec* GetAudioCodec() override {
#ifdef AUDIO_I2S_METHOD_SIMPLEX
    static NoAudioCodecSimplex audio_codec(
        24000, 24000,   // 改为24000！之前是16000
        I2S_SPK_BCLK_PIN, I2S_SPK_WS_PIN, I2S_SPK_DIN_PIN,
        I2S_MIC_BCLK_PIN, I2S_MIC_WS_PIN, I2S_MIC_DIN_PIN);
#else
    static NoAudioCodecDuplex audio_codec(24000, 24000,
        I2S_SPK_BCLK_PIN, I2S_SPK_WS_PIN, I2S_SPK_DIN_PIN,
        I2S_MIC_DIN_PIN);
#endif
    return &audio_codec;
}

    virtual Display* GetDisplay() override {
        return display_;
    }

    void SendUartText(const std::string& text) {
        std::string data = text + "\n";
        uart_write_bytes(UART_NUM_1, data.c_str(), data.size());
        ESP_LOGI(TAG, "UART send: %s", text.c_str());
    }
};

DECLARE_BOARD(MyEsp32Board);